# Kafka_서비스가_올라가_있지_않을

> 생성일시: 2026-08-27 18:10

## 질문

Kafka 서비스가 올라가 있지 않을 때 불필요하게 @KafkaListener 로 리스닝을 하지 않도록 하려면 어떻게 해야 할까?

---

## 답변

Kafka 관련 코드를 먼저 확인해볼게요.

---

## 답변

현재 `KafkaService`(`dstone-boot/.../sample/kafka/KafkaService.java`)를 보면 `ConfigKafka`는 `@ConditionalOnProperty("spring.kafka.enabled")`로 감싸져 있는데, `@KafkaListener`가 있는 `KafkaService`는 그냥 `@Service`라 이 조건과 무관하게 항상 빈으로 등록됩니다. Spring Kafka의 `@EnableKafka` 자동설정은 classpath에 kafka 라이브러리가 있으면 무조건 동작하므로, `spring.kafka.enabled: false`로 꺼도 리스너 컨테이너는 생성되어 부트스트랩 서버 연결을 계속 시도합니다.

추천: `@KafkaListener`에 `autoStartup = "${spring.kafka.enabled:false}"` 속성을 추가하는 것 — 리스너 컨테이너 자체는 빈으로 등록되지만 시작(연결 시도)을 하지 않아, 나중에 `KafkaListenerEndpointRegistry`로 수동 기동도 가능합니다. 대안으로 `KafkaService` 클래스 전체를 `ConfigKafka`처럼 `@ConditionalOnProperty(name="spring.kafka.enabled", havingValue="true")`로 감싸 빈 자체를 아예 등록 안 되게 하는 방법도 있는데, 이쪽이 더 확실히 끄지만 런타임에 켤 수 없고 재시작이 필요합니다.

어느 쪽으로 적용할지 정해주시면 바로 수정하겠습니다.

---

## 질문

지금 전체소스를 대상으로 @ConditionalOnProperty("spring.kafka.enabled")로 감싸져있는 부분이 없어

---

## 답변

`ConfigKafka.java` 21번 라인에는 실제로 `@ConditionalOnProperty(name = "spring.kafka.enabled", havingValue = "true")`가 있습니다 (git 상태도 clean이라 방금 확인한 그대로가 맞습니다). 다만 이건 **`KafkaTemplate` 빈**(producer 쪽)에만 걸려 있는 조건이고, `@KafkaListener`가 붙어있는 `KafkaService`(consumer 쪽)에는 이 조건이 없습니다 — 그래서 "감싸진 부분이 없다"고 느끼신 건 아마 리스너 쪽을 보신 게 맞을 겁니다.

즉 지금 상태를 정리하면:

| 클래스 | 어노테이션 | Kafka 꺼도 동작? |
|---|---|---|
| `ConfigKafka` (KafkaTemplate 빈) | `@ConditionalOnProperty(spring.kafka.enabled)` | 안 만들어짐 (OK) |
| `KafkaService` (`@KafkaListener`) | 없음 | **여전히 리스너 컨테이너가 뜨고 연결 시도함** |

`KafkaService`가 Kafka 꺼졌을 때 리스닝을 안 하게 하려면 다음 중 하나를 적용하면 됩니다.

**방법 1 — `autoStartup` 속성 (권장)**
```java
@KafkaListener(topics = "order-events", groupId = "inventory-service-group",
               autoStartup = "${spring.kafka.enabled:false}")
public void consume(Map<String,Object> param) { ... }
```
리스너 컨테이너 빈은 생성되지만 시작(브로커 연결)을 안 함. 나중에 `KafkaListenerEndpointRegistry`로 수동 기동 가능.

**방법 2 — 클래스 자체를 조건부 빈으로**
```java
@Service
@ConditionalOnProperty(name = "spring.kafka.enabled", havingValue = "true")
public class KafkaService extends BaseService { ... }
```
`ConfigKafka`, `ConfigMq`, `ConfigRedis` 등 기존 패턴과 통일되고 더 확실하게 꺼짐. 단, `publish()`(producer 메서드)까지 같이 사라지므로 다른 곳에서 이 빈을 주입받는 코드가 있으면 그쪽도 같이 꺼짐 — 이 서비스가 producer/consumer 겸용이면 문제, 각각 분리되어 있으면 무방.

`KafkaService`가 publish/consume을 겸하고 있어서 방법 2를 그대로 쓰면 producer 기능까지 통째로 꺼집니다. 어떤 방식으로 적용할까요?

---

## 질문

ConfigKafka 에서 통제할 방법은 없는건가?

---

## 답변

가능합니다. `KafkaService`에 있는 `@KafkaListener`는 별도로 `factory`를 지정하지 않았기 때문에 Spring Boot가 자동 생성하는 기본 `kafkaListenerContainerFactory` 빈을 사용합니다. 이 빈을 `ConfigKafka`에서 직접 정의(오버라이드)하면서 `autoStartup`을 프로퍼티 값으로 제어하면, **개별 `@KafkaListener`를 건드리지 않고 앱 전체의 리스너를 한 곳에서 통제**할 수 있습니다. Spring Boot 자동설정은 `kafkaListenerContainerFactory`라는 이름의 빈이 이미 있으면 자기 것을 만들지 않고 물러나므로(`@ConditionalOnMissingBean`), 이 방식이 정확히 동작합니다.

```java
@Configuration
public class ConfigKafka extends BaseObject {

    @Autowired
    ConfigProperty configProperty;

    @Bean
    @ConditionalOnProperty(name = "spring.kafka.enabled", havingValue = "true")
    public KafkaTemplate<String, Object> kafkaTemplate() {
        // 기존 로직 그대로
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.setAutoStartup(
                Boolean.parseBoolean(configProperty.getProperty("spring.kafka.enabled")));
        return factory;
    }
}
```

핵심 포인트:
- 클래스 레벨의 `@ConditionalOnProperty`는 제거하고(그대로 두면 `spring.kafka.enabled=false`일 때 `ConfigKafka` 자체가 로드되지 않아 이 오버라이드도 무력화됩니다), `kafkaTemplate()` 빈에만 메서드 레벨로 옮겨야 합니다.
- `ConsumerFactory<String, Object>`는 이미 Spring Boot가 `application.yml`의 `spring.kafka.consumer.*` 설정으로 자동 구성해주는 빈이라 그대로 주입받으면 됩니다.
- `KafkaService`, 앞으로 추가될 다른 `@KafkaListener` 클래스들도 별도 factory를 지정하지 않는 한 자동으로 이 통제를 받습니다.

원하시면 이대로 `ConfigKafka.java`에 적용하고 `KafkaService.java`는 그대로 둘까요, 아니면 지난번 얘기한 `KafkaService` 개별 `@ConditionalOnProperty`(producer/consumer 분리)까지 같이 적용할까요?

---

## 질문

<task-notification>
<task-id>bvlua13m1</task-id>
<tool-use-id>toolu_01XYNE7rsRM9jxHcvGPYNkhZ</tool-use-id>
<output-file>/tmp/claude-1000/-app-dstone/d6d9eadb-bcf8-4cff-9859-0c71bf4c521b/tasks/bvlua13m1.output</output-file>
<status>completed</status>
<summary>Background command "find / -name "spring-boot-autoconfigure-3*.jar" 2&gt;/dev/null | head -5; find / -iname "*spring-kafka*.jar" 2&gt;/dev/null | head -5" completed (exit code 0)</summary>
</task-notification>

---

## 답변

This was just my earlier background jar-search finishing — no action needed, still waiting on your answer about which approach to apply (`ConfigKafka` factory override only, or that plus splitting `KafkaService`).

---

## 질문

이 ConfigKafka를 적용하면 @KafkaListener 에서도 자동적용이 되는 건가?

---

## 답변

네, 자동 적용됩니다. `@KafkaListener`는 `containerFactory` 속성을 지정하지 않으면 스프링이 빈 이름 `"kafkaListenerContainerFactory"`를 기본값으로 찾아서 사용하는데, `KafkaService.consume()`도 이 속성을 안 썼기 때문에 방금 만든 `ConfigKafka`의 `kafkaListenerContainerFactory` 빈을 그대로 씁니다. 즉:

- 현재 `KafkaService`뿐 아니라, 앞으로 추가되는 어떤 `@KafkaListener`든 `containerFactory`를 명시하지 않는 한 전부 이 `autoStartup` 설정의 통제를 받습니다.
- 예외는 딱 하나, `@KafkaListener(..., containerFactory = "다른빈이름")`처럼 명시적으로 다른 factory를 지정한 경우뿐입니다 — 그런 경우는 개별로 따로 관리해야 합니다.

정리하면 `spring.kafka.enabled=false`일 때: 컨슈머 그룹 연결 시도 자체가 없어지고, 리스너 컨테이너는 등록만 된 채 멈춰있는 상태(`Stopped`)가 됩니다. 나중에 `true`로 바꾸고 재시작하면 정상 기동됩니다.

적용해드릴까요? (`ConfigKafka.java`만 수정, `KafkaService.java`는 그대로 둡니다)

---

## 질문

응 적용해주고 KafkaService 도 수정해줘

---

## 답변

Good, `warn()` is available. Now applying both edits.

---

## 답변

Now `KafkaService.java` — making the `KafkaTemplate` injection optional and guarding `publish()`, since with `kafkaTemplate()` still conditional on `spring.kafka.enabled=true`, an unconditional `@Autowired` would otherwise crash context startup when Kafka is disabled.

---

## 답변

Maven이 이 환경에 없어 컴파일 검증은 못 했습니다. 두 파일을 직접 검토해볼게요.

---

## 답변

생성자 주입할 `ConsumerFactory` 제네릭 타입을 다시 보니, Spring Boot가 자동구성하는 기본 `ConsumerFactory` 빈은 `ConsumerFactory<Object, Object>`로 등록됩니다. 제네릭은 무공변(invariant)이라 `ConsumerFactory<String,Object>` 파라미터로는 이 빈을 매칭 못 하고 기동 시 `NoSuchBeanDefinitionException`이 날 수 있어서, Boot 기본값과 동일하게 `<Object, Object>`로 맞춰야 합니다.

---

## 답변

`ConfigKafka.java`, `KafkaService.java` 두 파일 다 수정했습니다.

**`ConfigKafka.java`**
- 클래스 레벨 `@ConditionalOnProperty` 제거 → `kafkaTemplate()` 빈에만 옮김 (기존 동작 그대로 유지).
- `kafkaListenerContainerFactory` 빈을 새로 등록해 `spring.kafka.enabled` 값으로 `autoStartup`을 통제. `@KafkaListener`가 `containerFactory`를 명시하지 않으면 전부 이 빈을 타므로, `KafkaService`뿐 아니라 앞으로 추가되는 리스너도 자동으로 통제됨.
- 자동구성 기본 `ConsumerFactory` 빈이 `<Object, Object>` 제네릭으로 등록되므로, 매칭 실패 안 나게 동일한 타입으로 주입받도록 함.

**`KafkaService.java`**
- `KafkaTemplate` 주입을 `@Autowired(required = false)`로 변경 — `spring.kafka.enabled=false`일 때 `kafkaTemplate` 빈이 아예 없어져도 컨텍스트 기동이 깨지지 않음.
- `publish()`에 null 체크 추가 — 꺼진 상태에서 호출되면 예외 대신 경고 로그 후 조용히 리턴.

정리하면: `spring.kafka.enabled=false`일 때 — 리스너는 등록만 되고 브로커 연결 시도 없음, producer 호출도 NPE 없이 안전하게 무시됨. `true`로 바꾸면 재시작 후 둘 다 정상 동작합니다.
