# localcommandcaveatTh

> 생성일시: 2026-10-30 16:55

## 질문

<local-command-caveat>The command below was run directly in Claude Code, not sent to you as a request, and its output goes straight to the user. It's recorded here as context for later messages.</local-command-caveat>

---

## 질문

<command-name>/clear</command-name>
            <command-message>clear</command-message>
            <command-args></command-args>

---

## 질문

dstone-ai-engine 에 spring-ai-agent-utils 을 추가했어. 아래의 기능을 dstone-ai-engine 에 추가하고자 해. 계획을 세워줘.
- Agent Skills
- TaskTools – Sub-Agent 오케스트레이션

---

## 답변

라이브러리 API를 확인하려고 Maven Central에서 jar를 받아 클래스 구성을 살펴보는 중입니다.

---

## 답변

Now the engine side: the current Sub Agent, the tool-attach spot, the loader, and the reloader.

---

## 답변

계획을 정리했습니다. 라이브러리 소스(0.13.0)와 현재 엔진 코드를 같이 읽고 세웠습니다.

## 시작 전에 확인할 것

**의존성은 `/app/dstone`에 아직 없습니다.** `spring-ai-agent-utils` 0.13.0은 Windows 쪽 클론(`D:/AppHome/framework/dstone/dstone-ai-engine/pom.xml`, 128~133행)에만 들어가 있고 커밋도 되지 않았습니다. 작업은 `/app/dstone`에서만 하기로 했으니, 구현 첫 단계에서 이곳 pom에 같은 의존성을 넣겠습니다. 버전은 맞습니다. Spring AI는 2.0.1, Spring은 7.0.x 기준이고, 함께 들어오는 것은 `spring-ai-agent-utils-common`과 `flexmark-html2md-converter`입니다.

## 라이브러리를 읽고 확인한 점

| 기능 | 라이브러리가 하는 일 | 엔진에 그대로 쓰면 생기는 문제 |
|---|---|---|
| **SkillsTool** | `SKILL.md`(front matter `name`/`description` + 본문)를 읽고 `Skill` Tool 하나를 만듭니다. Tool 설명에는 Skill 목록이 들어가고, LLM이 이름으로 부르면 본문과 기준 폴더를 돌려줍니다. | 큰 문제는 없습니다. 다만 이름이 겹치면 경고만 남기고 넘어갑니다. 빌더의 `addSkill()`은 기준 폴더를 버리기 때문에 Agent마다 필요한 Skill만 골라 붙이기가 어색합니다. |
| **TaskTool / TaskOutputTool** | `Task` Tool 하나로 `subagent_type`을 골라 일을 맡깁니다. `run_in_background`로 백그라운드 실행을 하고, `TaskOutput`으로 결과를 받습니다. | 기본 실행기 `ClaudeSubagentExecutor`가 `ChatClient`를 직접 부르기 때문에 **`AgentExecutor`가 지키는 것들을 모두 건너뜁니다.** 엔진 규칙, `requestOptions()`(60초 타임아웃 문제), 입출력 계약 검사, `ToolCallBudgetCallback`, 결과 압축, `LimitedToolCallback`, 호출 로그가 빠집니다. Claude 종류로 등록하면 Explore/Plan/Bash 같은 내장 Sub Agent가 자동으로 붙는데, 이들은 우리에게 없는 Tool 이름(Read/Grep/Bash)과 Claude 모델 별칭을 씁니다. `model`/`resume` 인자는 무시됩니다(소스에 TODO로 남아 있음). 백그라운드 저장소 `DefaultTaskRepository`는 메모리 안의 무제한 스레드 풀입니다. |

따라서 **Skill은 라이브러리 부품을 그대로 쓰고, Task는 껍데기(`Task`/`TaskOutput` Tool, `TaskRepository`)만 쓰는** 방향을 권합니다. 실행기는 `SubagentType` 확장점에 엔진 전용 구현을 끼웁니다.

## 1. Agent Skills

**정의 위치와 형식**
- `conf/definitions/skills/<폴더>/<skill-name>/SKILL.md`에 둡니다. 같은 폴더의 참고 파일(`reference.md` 등)도 함께 둘 수 있습니다.
- `Constants.Definition`에 `skills/`를 추가합니다. `YamlDefinitionLoader`는 라이브러리의 `Skills.loadDirectory()`로 파싱합니다.

**Agent에서 쓰는 방법**
- Agent `.md` front matter에 `skills: {allowed: [name, ...]}`를 둡니다. `tools.allowed`와 같은 모양이고, `AgentDefinition.Skills` 레코드와 `skillNames()`를 추가합니다.

**구현**
1. `common.registry.SkillRegistry`를 새로 만듭니다. 이름으로 `Skill`을 찾고 기동 시 검사합니다. 이름 중복, 이름 형식(`[A-Za-z0-9_-]`), `description` 누락은 기동 실패로 처리합니다. 라이브러리는 이런 경우 경고만 남기지만, 다른 정의와 같은 기준을 적용합니다.
2. `AgentRegistry.check()`에서 모르는 Skill 이름을 쓰면 기동을 실패시킵니다. Tool 이름 `Skill`과 Sub Agent id가 겹치는지도 검사합니다.
3. `AgentExecutor.buildSpec()` 5단계에서 Agent의 Skill만 담은 `FunctionToolCallback("Skill", new SkillsTool.SkillsFunction(map))`을 붙입니다. 설명문은 우리 문구로 쓰고, `configTool.limited()`와 `budgeted()`로 감쌉니다. Agent마다 한 번 만들어 캐시하고, 정의를 다시 불러올 때 버립니다.
4. 참고 파일은 Agent가 `readFile`/`readFileLines`로 읽습니다. 그래서 **참고 파일이 있는 Skill을 쓰는 Agent는 `tools.allowed`에 `readFile`도 있어야 합니다.** 이 조건이 빠지면 경고를 남깁니다.
5. **Skill 안의 스크립트 실행은 1차 범위에서 뺍니다.** 라이브러리의 `ShellTools`는 우리 화이트리스트(`ShellExecTool`)를 우회합니다.
6. `DefinitionReloader`에 Skill을 포함합니다. 변경을 덧씌운 뒤 Skill → Agent → Workflow 순으로 검사하고, 모두 통과해야 반영합니다. 같은 경로로 `DefinitionController` 카탈로그와 `GET /api/ai/chat` 목록에도 Skill을 추가합니다.
7. 샘플은 `skills/sample/...` 1~2개와 이를 쓰는 `sample-skill-agent.md`, 시험용 Workflow 하나를 만듭니다.

## 2. TaskTools(Sub Agent 오케스트레이션)

**기존 `subAgents`와의 관계(권장안)**
- `subAgents`는 지금처럼 둡니다. 동기 실행, 타입이 있는 입력 스키마, 깊이 1 구조입니다.
- Task는 그 위에 **"LLM이 판단해서 여러 Agent를 동시에 돌리고 결과를 나중에 모으는"** 기능만 더합니다. 같은 일을 하는 경로가 둘이 되지 않게 하려는 것입니다.

**정의**
- Agent front matter에 `tasks: {agents: [id, ...], background: true|false}`를 둡니다. 맡길 대상은 기존 Agent `.md`이므로 새 파일 형식이 생기지 않습니다.
- `TaskCall.prompt`는 문자열이라서 **입력이 `string`인 Agent만 `tasks.agents`에 올 수 있습니다.** 그 밖의 입력이면 기동을 실패시킵니다.

**구현**
1. `runtime.agent.task.DstoneSubagentResolver`/`DstoneSubagentDefinition`을 만듭니다. kind는 `DSTONE`이고, id로 `AgentRegistry`의 정의를 찾습니다. Claude 종류가 아니므로 내장 Sub Agent는 붙지 않습니다.
2. `DstoneSubagentExecutor`는 `AgentExecutor.call()`로 실행합니다. 엔진 규칙 `SUB_AGENT`, 계약 검사, 예산, 타임아웃, 호출 로그가 모두 그대로 적용됩니다. 계약 위반은 `실패: ...` 응답으로 바꾸고, 시스템 오류는 그대로 던집니다. `SubAgentToolCallback`과 같은 규칙입니다.
3. `TaskRepository`는 **부모 Agent 호출 하나마다 새로 만듭니다.** 다른 호출이나 caller의 task를 보지 못하게 하기 위해서입니다. 스레드 풀은 공용 빈 하나로 두고 크기를 제한합니다(`dstone.ai.agent.task.max-concurrent`).
4. 부모 호출이 끝날 때 남은 task는 취소합니다. 이렇게 하면 Workflow step이 끝난 뒤에 task가 계속 도는 일이 없습니다.
5. 횟수 제한은 `dstone.ai.agent.sub-agent.max-calls`와 합산합니다. `TaskOutput` 대기 시간의 상한은 설정값으로 둡니다. 라이브러리 기본값은 30초이고 최대 600초입니다.
6. `resume`과 `model` 인자는 받지 않습니다. 모델은 Agent의 `model.name`을 따릅니다.
7. 1차 검증은 `ScriptedChatModel`로 합니다. Task 동기/백그라운드, `TaskOutput`, 취소, 입력이 문자열이 아닌 Agent 거부를 시험하고, 실제 LLM으로는 한 번 실행합니다.

**미리 알아 둘 한계**
- MCP 호출은 서버별로 직렬화되어 있습니다(`ConfigMcp.SerializedToolCallback`). 파일 편집 Tool도 잠금 하나를 공유합니다. 그래서 병렬로 돌려도 빨라지지 않는 경우가 있습니다.
- Workflow 단위의 병렬 처리는 이미 `forEach`로 할 수 있습니다. Task가 쓸모 있는 곳은 "몇 개로 나눌지 LLM이 정하는" 경우로 한정됩니다.

## 3. 공통 작업과 순서

1. pom 의존성 추가 → 빌드와 기동 확인(기존 28개 Agent / 20개 Workflow, 경고 0개)
2. Skills: 정의, 레지스트리, 실행, 재로딩, 샘플, 테스트
3. Tasks: Resolver/Executor, 범위 제한 저장소, 검사, 샘플, 테스트
4. 디자이너(`dstone-boot`): Agent 대화상자에 Skill/Task 칩을 넣습니다. 지금의 Tool/Sub Agent 칩과 같은 방식이고, Skill 파일 편집은 다음 단계로 미룹니다.
5. 문서: `docs/09.dstone-ai-engine.md` §7/§8(필드 설명과 템플릿), CLAUDE.md의 ai-engine 절

## 정해 주실 것

1. **Task와 `subAgents`의 관계:** 권장안(둘 다 두고 Task는 백그라운드·병렬용)과, `subAgents`를 Task로 통합하는 방안 중 어느 쪽으로 할까요? 통합하면 타입 있는 입력을 포기해야 합니다.
2. **Skill 스크립트 실행:** 1차에서 빼도 될까요?
3. **Claude 내장 Sub Agent(Explore/Plan/Bash/General):** 권장안대로 쓰지 않을까요?

정해 주시면 1단계(pom 반영과 기동 확인)부터 시작하겠습니다.

---

## 질문

Skill 은 LLM프로바이더 디펜던트 한건가?

---

## 답변

아니요. 이 라이브러리의 Skill은 LLM provider와 상관없이 동작합니다.

**동작 방식**

`SkillsTool`이 만드는 것은 Spring AI의 평범한 Tool 하나(`FunctionToolCallback`, 이름 `Skill`)입니다.

1. Tool 설명문에 Skill 목록(name, description)을 글로 넣어 LLM에 보냅니다.
2. LLM이 필요하다고 판단하면 `Skill(command="이름")`으로 Tool을 호출합니다.
3. 엔진이 해당 `SKILL.md` 본문을 읽어 Tool 결과로 돌려줍니다.

모두 일반 Tool 호출이라서 지금 엔진에 붙은 `readFile` 같은 Tool과 같은 경로를 탑니다. Anthropic, OpenAI/OpenRouter, Ollama 어디서든 Tool 호출만 지원하면 됩니다.

**헷갈리기 쉬운 것**

Anthropic API에도 "Agent Skills"라는 기능이 있는데, 이 라이브러리와는 별개입니다. 그쪽은 Skill을 Anthropic 서버에 올리고 코드 실행 컨테이너 안에서 돌리는 방식이라 Anthropic에서만 됩니다. Skill이라는 개념(`SKILL.md` + 필요할 때 불러오기)만 같고, 이 라이브러리는 그것을 Tool 호출로 흉내 낸 것입니다.

**모델에 따라 달라지는 점**

provider가 아니라 모델 능력에 따라 달라지는 부분은 있습니다.
- **Tool 호출 지원 여부:** Ollama는 모델마다 다릅니다. Tool 호출을 못 하는 모델이면 Skill도 못 씁니다.
- **Skill을 제때 고르는지:** description만 보고 알맞은 Skill을 고르는 능력은 모델마다 차이가 큽니다. 작은 모델은 Skill을 아예 부르지 않거나 엉뚱한 것을 부르기도 합니다. 그래서 계획에서처럼 Agent마다 `skills.allowed`로 후보를 좁혀 두는 편이 안전합니다.
- **본문이 긴 경우:** Skill 본문은 대화에 그대로 들어가므로 컨텍스트를 차지합니다. 우리 엔진의 결과 압축(`ToolResultCompactionAdvisor`)이 오래된 Tool 결과를 줄이는데, Skill 본문도 여기서 잘릴 수 있습니다. 구현할 때 Skill 결과를 압축 대상에서 뺄지 정해야 합니다.

정리하면, 지금 쓰는 OpenRouter `qwen/qwen3.8-27b`에서도 구조상으로는 그대로 쓸 수 있습니다. 실제로 Skill을 잘 골라 쓰는지는 구현 뒤에 한 번 돌려 봐야 압니다.

---

## 질문

기존 subAgents 와 Sub Agent 와의 차이점과 통합방법에 대해서 더 자세하게 설명해줘

---

## 답변

두 방식을 기능별로 비교하고, 합칠 수 있는 방법 세 가지를 정리했습니다.

## 1. 겉모습: LLM에게 무엇이 보이나

**기존 `subAgents`(우리 엔진):** 맡길 Agent 하나가 Tool 하나로 보입니다.
```
Tool 목록
├─ validateSqlSyntax(sql)
├─ sample-structured-extract-agent(input: string)        ← Agent id가 곧 Tool 이름
└─ sample-fix-agent(sql: string, error: string)          ← 자식의 input 스키마가 그대로 인자
```

**라이브러리 `TaskTool`:** Tool은 `Task` 하나뿐이고, 어떤 Agent에 맡길지는 인자로 고릅니다.
```
Tool 목록
├─ Task(description, prompt, subagent_type, model?, resume?, run_in_background?)
│      Tool 설명문 안에 "-explore: /설명", "-plan: /설명" 식의 목록
└─ TaskOutput(task_id, block?, timeout?)                  ← 백그라운드 결과 받기
```

## 2. 기능 비교

| 항목 | 기존 `subAgents` | 라이브러리 `TaskTool` |
|---|---|---|
| 인자 | **자식의 input 스키마 그대로**(object도 가능). 문자열 입력이면 `{input: …}`으로 감쌈 | `prompt` 문자열 하나. 구조화된 입력이 없음 |
| 입출력 검사 | `AgentExecutor.call()`이 input과 output 스키마를 모두 검사. 위반하면 `실패: …`로 돌려줘 부모가 고쳐서 다시 부름 | 없음. 자식 답 문자열을 그대로 돌려줌 |
| 실행 경로 | `AgentExecutor` → 엔진 규칙(`SUB_AGENT`), `requestOptions()`(타임아웃·reasoning), Tool 예산, 결과 압축, RAG 설정 | 기본 실행기가 `ChatClient`를 직접 부름. 위 장치가 모두 빠짐(교체 가능) |
| 자식 정의 | 기존 Agent `.md` 그대로 | Claude Code 형식 `.md`(`name`/`tools`/`disallowedTools`/`model`/`skills`). 내장 Explore/Plan/Bash/General이 자동으로 붙음 |
| **동시 실행** | 없음. 부르면 끝날 때까지 기다림 | **`run_in_background: true`로 맡기고 바로 돌아옴.** 나중에 `TaskOutput`으로 결과를 받음 |
| 이어서 시키기(resume) | 없음. 매번 빈 대화 | 인자는 있지만 기본 실행기가 **무시함**(구현 안 됨) |
| 모델 선택 | 자식 Agent의 `model.name` | 인자 `model`이 있지만 기본 실행기가 **무시함**. 정의 파일의 `model`은 반영 |
| 호출 횟수 제한 | `dstone.ai.agent.sub-agent.max-calls`(기본 10) | 없음 |
| 깊이 | 1단계(기동할 때 검사) | 제한 없음(자식에게 Task Tool을 주면 재귀) |
| 백그라운드 저장소 | 해당 없음 | 메모리 + 무제한 스레드 풀. 서버를 재시작하면 사라짐 |

정리하면 기존 `subAgents`가 라이브러리보다 **부족한 기능은 백그라운드 실행 하나뿐**입니다. 나머지(타입 있는 입력, 계약 검사, 엔진 장치, 횟수 제한)는 기존 방식이 더 엄격합니다. resume과 model 인자는 라이브러리에서도 실제로 동작하지 않습니다.

**병렬 실행에 대해 짚어 둘 점:** LLM이 한 번의 답에서 Sub Agent 세 개를 동시에 호출해도, 지금은 하나씩 차례로 실행된다고 알고 있습니다. Spring AI의 Tool 실행이 한 응답 안의 Tool 호출을 순서대로 처리하기 때문입니다. 2.0.1 소스로 직접 확인하지는 않았으니 구현 전에 확인하겠습니다. 그래서 "진짜 동시에 돌리기"는 백그라운드 실행 방식으로만 얻을 수 있습니다.

## 3. 통합 방법 세 가지

### 방법 A. 둘 다 두기(처음 계획)
```yaml
subAgents: [sample-fix-agent]                        # 기존: 동기, 타입 있는 입력
tasks: {agents: [sample-investigator-agent], background: true}   # 새로: Task Tool
```
- 장점: 기존 코드를 건드리지 않습니다.
- 단점: 일을 맡기는 방법이 두 가지가 되어, YAML을 쓰는 사람이 언제 무엇을 쓸지 헷갈립니다. Task 쪽은 문자열 입력만 받을 수 있습니다.

### 방법 B. `subAgents` 하나로 합치고, 라이브러리의 백그라운드 부품만 가져오기 ← **권장**
```yaml
subAgents:
  agents: [sample-structured-extract-agent, sample-fix-agent]
  background: true          # 생략하면 false = 지금과 똑같이 동작
```
LLM에게는 이렇게 보입니다.
```
├─ sample-fix-agent(sql, error, run_in_background?)   ← 기존 Tool에 인자 하나 추가
├─ sample-structured-extract-agent(input, run_in_background?)
└─ TaskOutput(task_id, block?, timeout?)               ← background: true일 때만 붙음
```
- `SubAgentToolCallback`은 그대로 두고, `background: true`일 때만 인자 스키마에 `run_in_background`를 덧붙입니다.
- `run_in_background`가 참이면 라이브러리의 `TaskRepository.putTask()`에 실행을 맡기고 `task_id`를 바로 돌려줍니다. 실행 자체는 지금처럼 `AgentExecutor.call()`로 합니다.
- `TaskOutput` Tool은 라이브러리 `TaskOutputTool`을 그대로 씁니다.
- 라이브러리의 `Task` Tool(문자열 `prompt` 하나)과 Claude 형식 정의 파일, 내장 Sub Agent는 **쓰지 않습니다.**
- 장점: 맡기는 방법이 하나로 유지됩니다. 타입 있는 입력과 계약 검사도 그대로 남습니다. 백그라운드는 원하는 Agent만 켭니다.
- 단점: 라이브러리에서 가져오는 것이 저장소와 `TaskOutput` 정도라 "TaskTool을 도입했다"고 하기에는 작습니다.

### 방법 C. 라이브러리 `Task` Tool로 완전히 바꾸기
```yaml
subAgents: [sample-structured-extract-agent, sample-fix-agent]   # 형식은 그대로, 내부만 Task로
```
- `TaskTool.builder().subagentTypes(new SubagentType(우리Resolver, 우리Executor))`로 만들고, 실행기 안에서 `AgentExecutor.call()`을 부릅니다.
- 단점이 큽니다.
  - Tool 인자가 `prompt` 문자열 하나로 줄어, `sample-fix-agent`처럼 object를 받는 Agent는 LLM이 JSON을 글로 써서 넘겨야 합니다. 스키마가 Tool 정의에서 사라지므로 틀리는 일이 늘어납니다.
  - Tool 설명문이 Claude Code용 문구(Read/Glob Tool 언급, 코드 예시)라서 바꿔 써야 합니다.
  - 지금 잘 돌아가는 `sample-subagent-orchestrator-agent`와 `pilot-source-investigator-agent`의 동작이 바뀌어 다시 측정해야 합니다.

## 4. 방법 B를 고를 때 바뀌는 것

| 위치 | 변경 |
|---|---|
| `AgentDefinition` | `subAgents`가 목록이면 지금처럼 읽고, `{agents, background}` 모양도 받음. 기존 파일은 고치지 않아도 됨 |
| `SubAgentToolCallback` | `background`면 `run_in_background` 인자를 더하고, 참일 때 저장소에 넣은 뒤 `task_id`를 돌려줌 |
| `AgentExecutor.subAgentCallbacks()` | 부모 호출 한 번마다 `TaskRepository`를 새로 만들고, `TaskOutputTool`을 붙임. 부모 호출이 끝나면 남은 task를 취소함 |
| 공용 스레드 풀 | 크기를 제한함(`dstone.ai.agent.sub-agent.max-concurrent`). 무제한 풀은 쓰지 않음 |
| 횟수 제한 | 백그라운드 호출도 `max-calls`에 포함 |
| 로그 | 백그라운드 스레드에서도 `parent → child` 로그를 남김. 호출 로그와 `execution.log`가 섞이지 않게 task_id를 붙임 |
| 엔진 규칙 | `background`일 때 "맡긴 뒤 `TaskOutput`으로 결과를 모두 받고 나서 답하라"는 규칙을 `EnginePrompt`에 추가 |
| 디자이너 | Agent 대화상자의 Sub Agent 칩 옆에 "동시 실행" 체크박스 |

## 5. 어떤 경우에 쓸모 있나

- **쓸모 있는 경우:** LLM이 상황을 보고 몇 갈래로 나눌지 정하는 조사형 Agent. 예를 들어 일반 경로에서 진입점 세 곳을 `pilot-source-investigator-agent` 셋에게 동시에 맡기는 경우입니다. 지금은 차례로 돌아서 진입점 수만큼 시간이 늘어납니다.
- **쓸모 없는 경우:** 나눌 대상이 미리 정해진 일. 이런 일은 Workflow `forEach`가 더 낫습니다. 이미 병렬로 돌고, 결과가 `state`에 남고, 테스트하기도 쉽습니다.
- **제약:** OpenRouter의 동시 요청 한도, MCP 서버별 직렬화, 파일 편집 Tool의 공용 잠금 때문에 동시에 맡겨도 기대만큼 빨라지지 않을 수 있습니다.

방법 B로 진행할까요? 정해 주시면 Skill 작업과 묶어서 구현 순서를 다시 짜겠습니다.

---

## 질문

응 방법B로 진행할 때 sub agent 가 내부적으로 또다른 sub agent 를 호출할 수 없는건가?

---

## 답변

네. 지금 규칙대로라면 Sub Agent는 다른 Sub Agent를 부를 수 없습니다. 방법 B는 이 규칙을 건드리지 않으므로 그대로 유지됩니다. 다만 이 제한은 실행 구조 때문이 아니라 기동 검사에서 막는 것이라 풀 수 있습니다.

## 지금 막히는 지점

`AgentRegistry.checkSubAgents()`(`common/registry/AgentRegistry.java:306`)가 기동할 때 이렇게 검사합니다.

```
agent[A]의 subAgents 'B': 이 Agent도 subAgents를 가지고 있습니다.
Sub Agent는 한 단계만 둘 수 있습니다(부모 → 자식).
```

실행 코드에는 깊이 제한이 없습니다. `SubAgentToolCallback`은 자식을 `AgentExecutor.call()`로 부르고, 그 안의 `buildSpec()`이 자식의 `subAgents`도 똑같이 Tool로 붙입니다. 이 검사 한 줄이 세 가지를 함께 막고 있습니다.

- 손자 호출(A → B → C)
- 자기 자신 호출(A → A)
- 순환 호출(A → B → A)

## 한 단계로 묶어 둔 이유

1. **순환 방지:** "자식은 `subAgents`를 가질 수 없다"는 규칙 하나면 순환 검사가 따로 필요 없습니다.
2. **비용 폭증 방지:** 지금 횟수 상한(`max-calls` 10)은 부모 호출 한 번 안에서만 셉니다. 깊이를 풀면 10 × 10 × 10번까지 LLM 호출이 늘어날 수 있습니다.
3. **추적 가능성:** 로그가 `parent → child` 한 줄로 끝납니다.

## 여러 단계를 허용하려면

방법 B와 함께 하거나 따로 할 수 있습니다. 바꿀 것은 다음과 같습니다.

| 항목 | 변경 |
|---|---|
| 깊이 상한 | `dstone.ai.agent.sub-agent.max-depth`(기본 1 = 지금과 같음). 기동 검사도 "자식이 `subAgents`를 가지면 실패"에서 "그래프 깊이가 상한을 넘으면 실패"로 바꿈 |
| 순환 검사 | 기동할 때 `subAgents` 그래프에서 순환(A → B → A, A → A)을 찾아 실패 처리. 깊이 검사만으로는 순환을 못 막기 때문에 따로 필요함 |
| 실행 중 깊이 | 호출 체인에 현재 깊이를 실어 보내 실행 중에도 상한을 확인. 정의를 다시 불러오는 도중 같은 틈을 막는 이중 방어 |
| 횟수 상한 | **최상위 호출 하나가 만든 트리 전체에서 공유하는 카운터** 하나로 셈. 단계마다 따로 세면 곱으로 늘어남 |
| 로그 | `A → B → C`처럼 경로 전체를 남김 |
| 엔진 규칙 | 중간 단계 Agent는 `SUB_AGENT` 규칙("결과만 답하라")을 받으면서 동시에 자기 자식에게 일을 맡김. 규칙 문구가 충돌하지 않는지 확인 |

## 방법 B(백그라운드)와 겹칠 때 주의할 점

깊이를 풀면서 백그라운드도 켜면 **스레드 풀 교착**이 생길 수 있습니다.

```
공용 풀 크기 4
A가 B1~B4를 백그라운드로 맡김 → 풀 4칸이 모두 참
B1이 C1을 백그라운드로 맡기고 TaskOutput으로 기다림 → C1은 빈 칸이 없어 시작 못 함
B1~B4가 모두 이렇게 기다리면 아무것도 끝나지 않음
```

막는 방법은 두 가지입니다.
- **백그라운드는 최상위 Agent에게만 허용**합니다. 중간 단계 Agent의 `background: true`는 기동할 때 막습니다. 가장 단순하고 안전합니다.
- 깊이마다 풀을 따로 두는 방법도 있지만 설정과 코드가 복잡해집니다.

## 권장

1. 방법 B는 **깊이 1을 유지한 채로** 먼저 구현합니다.
2. 깊이 확장이 필요하면 바로 이어서 `max-depth`를 추가합니다. 순환 검사, 트리 전체 카운터, 경로 로그도 같이 넣고, **백그라운드는 최상위만** 허용합니다. `max-depth`는 기본 1로 두므로 기존 정의는 동작이 바뀌지 않습니다.

실제로 2단계가 필요한 사례가 있는지에 따라 2번을 바로 할지 정하면 됩니다. 예를 들어 `pilot-source-investigator-agent`가 다시 하위 조사를 맡겨야 하는 경우가 있는지 알려 주시면 그에 맞추겠습니다.

---

## 질문

그래 스킬 + B안 으로 진행하자.

---

## 답변

Skill과 B안으로 진행하겠습니다. 먼저 손댈 코드(Agent 정의 레코드, 로더, 레지스트리, 실행기, 재로딩)를 읽겠습니다.

---

## 답변

Now the registry, reloader and executor in full.

---

## 답변

의존성은 그사이 git으로 이미 들어와 있습니다. 컴파일로 의존성을 받는지 확인합니다.

---

## 답변

컴파일은 통과합니다. 이제 Skill 정의부터 작성합니다. 먼저 상수와 정의 레코드입니다.

---

## 답변

Skill 정의 레코드를 만듭니다.

---

## 답변

Loader에 Skill 읽기를 추가합니다.

---

## 답변

이제 SkillRegistry를 만듭니다.

---

## 답변

이제 AgentDefinition에 `skills`를 추가하고, `subAgents`가 목록과 `{agents, background}` 두 모양을 모두 받도록 바꿉니다.

---

## 답변

AgentRegistry에 Skill 검사와 background 검사를 넣습니다.

---

## 답변

이제 Skill Tool을 만드는 `SkillTool`입니다. 라이브러리의 `SkillsTool.Skill`/`SkillsInput`을 쓰고, 설명문과 답은 엔진 형식으로 씁니다.

---

## 답변

Now I'll update `SubAgentToolCallback` so it takes the background argument.

---

## 답변

이제 AgentExecutor에서 Skill Tool을 붙이고, 부모 호출마다 `SubAgentTasks`를 만들고 닫도록 고칩니다.

---

## 답변

이제 DefinitionReloader가 Skill도 함께 다시 읽고 검사하도록 고칩니다.

---

## 답변

Catalog API에 Skill 목록과 Agent별 `skills`, `subAgentBackground`를 추가합니다.

---

## 답변

Compile once to check.

---

## 답변

컴파일이 통과합니다(테스트 포함). 이제 샘플 정의를 만듭니다. 기존 Sub Agent 샘플 Workflow와 테스트를 참고하겠습니다.

---

## 답변

샘플 정의를 만듭니다. 기존 Agent 파일 형식을 하나 보고 맞추겠습니다.

---

## 답변

Skill 샘플(본문 + 참고 파일)을 만듭니다.

---

## 답변

이제 Skill을 쓰는 Agent와, 그 Agent에게 백그라운드로 일을 맡기는 Agent를 만듭니다.

---

## 답변

샘플 정의를 만들었습니다. 이제 테스트를 작성합니다. 기존 테스트 하나를 보고 형식을 맞추겠습니다.

---

## 답변

Now I'll write the tests. First, the Skill tests.

---

## 답변

Next, the background Sub Agent tests: one end-to-end, plus a direct `SubAgentTasks` check that needs no LLM.

---

## 답변

LLM 흐름 테스트 4개가 건너뛰어졌습니다. `dstone.ai.test.llmcall` 값을 확인하겠습니다.

---

## 답변

The user set it to `true` in config. Override to `false` for this run only.

---

## 답변

`getContents()`에는 Tool 결과가 빠집니다. 대역에 Tool 결과까지 합친 글자를 돌려주는 도우미를 넣고, 테스트가 그것을 쓰게 바꿉니다.

---

## 답변

새 테스트 13개가 모두 통과합니다. 대역 옵션을 바꿨으니 전체 테스트를 돌려 기존 테스트에 영향이 없는지 확인합니다.

---

## 답변

You've hit your weekly limit · resets 12pm (Asia/Seoul)

---

## 질문

진행해줘.

---

## 답변

전체 46개 중 `sm/WorkFlowTest` 하나만 오류입니다. 제 변경 때문인지 원인부터 보겠습니다.

---

## 답변

제 변경과 무관한 기존 문제입니다. 테스트가 `step00_01_readReq`를 찾는데 Workflow 정의에는 그 id가 없습니다. 확인합니다.

---

## 답변

둘 다 DONE으로 끝났고 Skill 호출과 백그라운드 3건 동시 실행이 로그에 보입니다. 그런데 출력이 비어 있어서, state를 찍어 한 번 더 확인하겠습니다.

---

## 답변

Edits for sections 0.3, 3, 6.4 and 7.1.

---

## 답변

`docs/09.dstone-ai-engine.md` 정리를 마무리하는 중입니다. 다른 문서에 디자이너 Agent 창 설명이 있는지 확인한 뒤 CLAUDE.md를 갱신하겠습니다.

---

## 답변

CLAUDE.md에도 이번 결정 사항을 한 단락으로 남깁니다(영문, 기존 형식).

---

## 답변

Skill 기능과 B안(Sub Agent 백그라운드 실행)을 구현했습니다. 미리 넣어 둔 답으로 도는 테스트는 46개 중 45개가 통과했고, 실제 LLM(OpenRouter)으로도 두 샘플을 한 번씩 끝까지 돌렸습니다. 커밋은 하지 않았습니다.

## 쓰는 방법

**Skill**
```yaml
skills:
  allowed: [sql-review]   # conf/definitions/skills/<폴더>/sql-review/SKILL.md
```
- LLM에게는 `Skill`이라는 Tool 하나로 보입니다. 설명에는 Skill의 이름과 설명만 들어가고, 본문은 LLM이 부를 때만 받습니다.
- `SKILL.md`는 공개 Agent Skills 형식 그대로입니다(`name`, `description`). `name`은 폴더 이름과 같아야 합니다.
- 같은 폴더의 참고 파일은 Agent가 `readFile`로 읽습니다. 그래서 그런 Skill을 쓰는 Agent는 `tools.allowed`에 `readFile`이 있어야 하고, 없으면 기동할 때 경고가 남습니다.
- Skill 안의 스크립트 실행은 넣지 않았습니다(셸 화이트리스트를 우회하게 되므로).

**Sub Agent 백그라운드(B안)**
```yaml
subAgents:
  agents: [sample-skill-agent]
  background: true
```
- 기존처럼 목록으로 적은 Agent는 동작이 바뀌지 않습니다.
- `background: true`면 Sub Agent Tool에 `run_in_background` 인자가 생기고 `TaskOutput` Tool이 함께 붙습니다.
- 자식은 지금처럼 `AgentExecutor.call()`로 부릅니다. 그래서 타입 있는 입력, 계약 검사, 엔진 규칙, 시간 제한이 그대로 적용됩니다.
- 맡긴 일은 부모 호출 한 번 동안만 살아 있습니다. 부모가 결과를 받지 않고 끝나면 남은 일은 끊깁니다.
- 스레드는 엔진 전체가 함께 쓰는 풀에서 빌립니다(`dstone.ai.agent.sub-agent.background-threads`, 기본 4).
- 깊이는 1단계 그대로입니다.

## 확인한 것
- **테스트(미리 넣은 답)**: 새로 넣은 13개를 포함해 45개 통과.
- **실패 1개**: `workflow/sm/WorkFlowTest`. `sm-workflow`의 step id가 `step01_readCustReq` 식으로 바뀌었는데 테스트는 아직 예전 id `step00_01_readReq`를 씁니다. 이번 변경과는 무관하고 작업 중이신 부분이라 손대지 않았습니다.
- **실제 LLM, Skill**: Skill 호출 → 문법 검사 실패 → `checklist.md` 읽기 → `FORM`을 `FROM`으로 수정 → 재검사 통과까지 약 10초.
- **실제 LLM, 백그라운드**: SQL 3개를 동시에 맡겼고, 6~25초 걸린 자식 3개의 결과를 `TaskOutput`으로 모아 44초에 끝났습니다.
- **디자이너 화면**: Agent 창에 Skill 칩과 "기다리지 않고 맡길 수 있게 함(background)" 체크를 넣었습니다. JS 문법 검사만 했고, 브라우저에서 눌러 보지는 않았습니다.

## 알아 두실 점
- `conf/application.yml`의 `dstone.ai.test.llmcall`이 `true`로 되어 있어서, 미리 넣은 답으로 도는 테스트는 기본 설정에서 건너뜁니다. 저는 `-Ddstone.ai.test.llmcall=false`를 붙여 돌렸습니다.
- 이 테스트들이 Tool 호출 흐름을 시험할 수 있도록 테스트 대역(`ScriptedChatModel`)을 고쳤습니다. 지금까지는 대역이 Tool을 요청에 싣지 않아서, Tool 호출 답을 넣어도 실행되지 않았습니다.
- **추가한 샘플**: Skill `skills/sample/sql-review`, Agent `sample-skill-agent`·`sample-subagent-background-agent`, Workflow `sample-agent-skill`·`sample-agent-subagent-background`.
- **갱신한 문서**: `docs/09.dstone-ai-engine.md`, `docs/06.dstone-boot.md`, `CLAUDE.md`.

---

## 질문

올려줘.

---

## 답변

이 저장소는 main에 바로 커밋하고 올리는 방식이라 그대로 따르겠습니다. 이번 작업 파일만 커밋합니다.

---

## 답변

Skill과 Sub Agent 백그라운드 실행 작업을 커밋 `b13151df`로 GitHub `main`에 올렸습니다. 로컬과 원격이 같은 상태인 것까지 확인했습니다.

- **올린 범위:** 이번 작업 파일 29개(코드, 샘플 정의, 테스트, 디자이너 JS, 문서 3개)만 넣었습니다.
- **브랜치:** 이 저장소는 그동안 main에 바로 올려 왔기 때문에 별도 브랜치 없이 main에 커밋했습니다.

Windows 쪽 클론(`D:/AppHome/framework/dstone`)에는 pom 변경이 커밋되지 않은 채로 남아 있습니다. 같은 내용이 이미 main에 들어가 있으니, 그쪽에서 pull하기 전에 그 변경을 되돌리거나 stash해 두시면 충돌이 나지 않습니다.
