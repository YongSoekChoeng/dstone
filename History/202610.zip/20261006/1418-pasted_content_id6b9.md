# pasted_content_id6b9

> 생성일시: 2026-10-06 14:18

## 질문

<pasted_content id="6b9e">
dstone-knowledge 에서 전체 호출구조를 비주얼하게 한눈에 볼 수 있는 노드(Node)맵 기능을 넣을 수 있겠는가?
1. 전체 노드맵 조회
2. 특정 노드를 선택했을 때 해당 노드와 관계를 맺는 노드트리들만 강조 혹은 별도 팝업
3. 선택된 특정 노드에 대한 상세설명 노출
</pasted_content id="6b9e">

---

## 답변

가능 여부를 정확히 답하려고, 지금 있는 관계 API와 화면 구조부터 확인하겠습니다.

---

## 답변

네, 넣을 수 있습니다. 분석 결과가 이미 관계 테이블(`analysis_relation`)에 그래프 형태로 쌓여 있어서 분석 단계는 손댈 필요가 없고, 조회 API 2~3개와 `dstone-boot` 화면 1개만 추가하면 됩니다. 아직 구현은 시작하지 않았습니다.

다만 1번 "전체 노드맵"은 메서드 단위로 그대로 그리면 쓸 수 없습니다. `anybiz_prd`만 해도 메서드가 14,762개라 브라우저가 버티기 어렵고, 그려져도 읽을 수 없습니다. 그래서 전체 보기는 묶어서 보여주고, 필요한 곳만 펼치는 방식을 권합니다.

## 요구사항별 구현 방안

| 요구사항 | 방안 | 지금 있는 것 | 새로 필요한 것 |
|---|---|---|---|
| 1. 전체 노드맵 | 클래스(타입) 단위로 묶은 지도. 노드는 클래스·SQL문·테이블·JSP, 선은 메서드 호출을 클래스 간으로 합친 것(굵기는 호출 수). 계층(Controller/Service/DAO)별 색상과 패키지·계층 필터 | 관계 데이터, 계층 정보 | 묶음 그래프 API (`GET /api/revisions/{id}/graph`) |
| 2. 선택 노드의 관계 트리 | 노드를 누르면 위쪽(호출하는 쪽: 화면 → 엔드포인트)과 아래쪽(호출되는 쪽: SQL → 테이블)으로 이어진 노드만 강조하고 나머지는 흐리게. "따로 보기" 버튼으로 그 부분만 팝업에 메서드 단위로 표시 | 영향 분석의 위쪽 탐색 쿼리, `/callers`·`/callees` (깊이 5 제한) | 한 노드 기준 양방향 부분 그래프 API |
| 3. 상세설명 | 오른쪽 패널에 종류, 계층, 파일·줄 번호, 엔드포인트 경로, 호출/피호출 수, 실행 SQL, 사용 테이블, 주석, 소스 일부 표시 | `/symbols/{symbolId}`, RAG 문서 본문 | 노드 종류별 상세를 한 번에 주는 API (기존 조회 조합) |

## 미리 알아둘 점

- **그래프 라이브러리**: `dstone-boot`에 그래프 라이브러리가 없어서 하나 추가해야 합니다. Cytoscape.js를 권합니다. 계층형 배치, 이웃 강조, 수천 노드 처리가 기본 기능입니다.
- **큰 프로젝트**: 클래스 단위로 묶어도 `anybiz_prd`는 노드가 수천 개가 될 수 있습니다. 처음에는 패키지 단위로 접어서 보여주고 눌러서 펼치거나, 노드 수 상한과 필터를 두어야 합니다.
- **신뢰도 표시**: `LOW` 관계는 추정이므로 점선으로 구분하고 기본은 숨기는 편이 좋습니다.
- **기존 규칙 유지**: 화면은 `dstone-boot`의 프록시(`/knowledge/api/call.do`)를 그대로 쓰고, 순환 방어(깊이 제한, 중복 제거)도 기존 쿼리와 같은 방식으로 넣습니다.

## 작업 범위

- `dstone-knowledge`: `GraphService`, 컨트롤러 엔드포인트 3개, `RelationDao.xml` 쿼리 추가, 단위 테스트
- `dstone-boot`: 화면 1개(`knowledge/graph/graph.jsp`, `graph.js`), 메뉴 링크, 안내 페이지 보강
- 문서: `docs/11.dstone-knowledge.md`, `CLAUDE.md`
- 검증: `struts-app`(작은 샘플, 기대값 있음)과 `anybiz_prd`(큰 실물)

## 진행 전에 정해주실 것

1. **전체 보기 단위**: 클래스 단위 + 패키지 접기로 진행해도 될까요? 메서드 단위 전체 표시는 권하지 않습니다.
2. **라이브러리 반입 방식**: Cytoscape.js 파일을 `dstone-boot/webapp` 아래에 직접 넣어도 될까요? 폐쇄망 SI 환경을 생각하면 CDN보다 이쪽이 안전합니다.

두 가지가 괜찮으시면 바로 구현하겠습니다.

---

## 질문

응 괜찮아.

---

## 답변

진행하겠습니다. 먼저 기존 코드(컨트롤러, 관계 쿼리, 스키마, 화면 공통 스크립트)를 읽겠습니다.

---

## 답변

Now writing the backend. SQL first.

---

## 답변

화면 코드(JSP, 스크립트, 스타일, 메뉴 링크) 작성을 마쳤고, 지금은 헤드리스 브라우저로 실제 화면을 띄워 동작과 모양을 확인하는 중입니다.

---

## 답변

`dstone-boot`를 빌드하는 동안(실제 JSP와 로그인 경로로 한 번 더 확인하기 위함) 문서를 갱신하고 있습니다.

---

## 답변

문서 갱신 스크립트가 앞 단계에서 중단돼 적용되지 않았습니다. 지금 `docs/11`과 `CLAUDE.md` 갱신을 다시 적용하고 마무리 점검을 합니다.

---

## 답변

노드 맵 기능을 넣었습니다. `dstone-boot`의 "코드 분석(Knowledge)" 위쪽 메뉴에 **노드 맵**이 생겼고, 요청하신 세 가지가 모두 동작합니다. 커밋은 하지 않았습니다.

## 만든 것

1. **전체 노드맵**: 클래스·화면(JSP)·SQL 매퍼·테이블을 노드로, 화면 → 컨트롤러 → 서비스 → DAO → SQL 매퍼 → 테이블 순으로 왼쪽에서 오른쪽으로 그립니다.
   - 노드가 250개를 넘으면 패키지(폴더) 묶음으로 접혀서 나오고, 묶음을 두 번 누르면 펼쳐집니다. `anybiz_prd`는 1,434개가 241개로 접혀 나옵니다.
   - 계층별 켜고 끄기, 이름으로 찾기, 자유 배치가 있습니다.
2. **선택 노드의 관계 강조와 팝업**:
   - 노드를 누르면 이어진 것만 남고 나머지는 흐려집니다. 부르는 쪽은 파란 테, 불리는 쪽은 주황 테입니다.
   - "관계 트리 따로 보기"를 누르면 메소드 단위 트리가 팝업으로 열립니다. 가운데가 고른 노드, 왼쪽이 부르는 쪽, 오른쪽이 SQL·테이블까지 불리는 쪽입니다.
3. **상세설명**: 오른쪽 패널에 위치, 계층, 처리하는 주소, 메소드나 SQL 목록, 그리고 분석이 이미 만들어 둔 설명 문서(검색에 쓰는 것과 같은 글)를 보여줍니다.

## 알아두실 점

- **전체 맵의 강조는 실제 호출 경로보다 넓게 켜집니다.** 클래스끼리의 선을 따라가기 때문에, 실제로는 이어지지 않는 길도 포함됩니다. 정확한 경로는 팝업 트리로 보셔야 합니다.
- **큰 프로젝트는 "바로 옆만" 강조로 시작합니다.** 공통 클래스(`CommUtil`, `BaseService`)를 거치면 거의 전부가 이어지기 때문입니다. 범위는 화면에서 바꿀 수 있습니다.
- **모델(VO) 계층은 기본으로 꺼져 있습니다.** getter/setter 호출이 그림을 덮습니다.
- **어디서나 쓰이는 클래스는 트리가 잘립니다.** `BaseService` 같은 클래스는 한 방향 3,000개 한도에 걸리므로, 메소드 하나를 골라서 보셔야 합니다.
- **자유 배치는 느립니다.** 노드 244개에 4초가 걸려서 400개까지만 허용했습니다.
- **중계 한도를 늘렸습니다.** `dstone-boot` 중계의 응답 한도가 256KB라 `anybiz_prd` 전체 맵(약 1MB)이 502로 막혔고, `KnowledgeProxyService`에서 32MB로 올렸습니다.

## 확인한 것

- `struts-app` 전체 맵의 관계 수가 표본 README의 기대값과 일치합니다.
- `anybiz_prd`는 전체 맵 1.3초, 보통 클래스의 트리 0.1~1초입니다.
- `dstone-boot`를 로컬로 띄워 로그인한 뒤 헤드리스 Chromium으로 실제 화면을 그려 확인했습니다. 노드 누르기와 강조, 묶음 펼치기/접기, 찾기, 트리 팝업, 상세까지 마우스 조작으로 통과했고 콘솔 오류는 없습니다.
- 사람이 직접 써 본 것은 아니므로, 배치나 색 같은 사용감은 한번 봐주시면 좋겠습니다.

## 실행 상태

- `dstone-knowledge`(4081)는 새 jar로 다시 띄워 둔 상태입니다. `bin/*.sh`에 실행 권한이 없어 `bash bin/startApp.sh`로 실행했습니다.
- 확인용으로 띄웠던 로컬 `dstone-boot`(7081)는 내렸습니다. 화면을 보시려면 `dstone-boot`를 새 war로 다시 배포해야 합니다.
- Cytoscape.js 3.34.3(MIT)은 `dstone-boot/src/main/webapp/knowledge/assets/lib/`에 넣었습니다.

문서는 `docs/11.dstone-knowledge.md`(4.18절, API 표, 현재 상태)와 `CLAUDE.md`, 화면의 사용 안내 페이지를 함께 갱신했습니다.

---

## 질문

dstone-knowledge 서버 내려줘

---

## 답변

`dstone-knowledge` 서버를 내렸습니다. 프로세스가 없고 4081 포트도 닫힌 것을 확인했습니다.

다시 띄울 때는 `bin/*.sh`에 실행 권한이 없으므로 `bash bin/startApp.sh`로 실행하시면 됩니다.

---

## 질문

dstone-ai-engine 어플리케이션의 db 접근 방식을 MyBatis로 수정해줘.
그리고 rag 기능을 dstone-knowledge 와 연동해서 진행할 수 있도록 수정해줘.

---

## 답변

먼저 `dstone-ai-engine`이 지금 DB를 어떻게 쓰는지와 RAG 관련 코드를 확인하겠습니다.

---

## 답변

두 가지 모두 반영했고, 로컬에서 두 서버를 띄워 실제로 확인했습니다. 커밋은 하지 않았습니다.

## 1. DB 접근을 MyBatis로

- **바뀐 곳**: JdbcTemplate을 쓰던 곳은 실행 이력 저장소(`WorkFlowExecutionStore`)와 문서 목록 조회 두 군데였습니다. 전자는 MyBatis Dao로 바꿨고, 후자는 RAG 이관으로 DB 조회 자체가 없어졌습니다.
- **구성**: SQL은 `resources/sqlmap/workflow/WorkFlowExecutionDao.xml`에 있고, `common.config.ConfigMapper`와 `common.biz.BaseDao`를 추가했습니다. DataSource는 기존 `spring.datasource.*` 설정을 그대로 씁니다.
- **확인**: Tool 워크플로 실행, 승인 대기 → 재개, 실행 목록/상세/스텝 이력 조회가 모두 정상입니다.

## 2. RAG를 dstone-knowledge와 연동

`dstone-ai-engine`은 이제 임베딩 모델도 pgvector도 갖지 않고, 문서 저장·임베딩·검색을 모두 `dstone-knowledge` API에 맡깁니다.

| 기능 | 지금 동작 |
|---|---|
| 문서 올리기 / 삭제 / 목록 | `dstone-knowledge`의 `/api/documents`로 전달 |
| 검색 (`searchDocuments` Tool, `/api/ai/rag/search`) | `dstone-knowledge`의 `/api/search` 호출 후 걸러서 반환 |
| Agent의 `ragEnabled` | 그대로 유지. 검색하는 부분만 교체 |
| `dstone-ai-engine`의 API 주소와 응답 모양 | 그대로. `dstone-boot`의 문서 관리 화면 코드는 고치지 않음 (화면에서 직접 눌러 보지는 않음) |

확인한 것: 시험 문서를 올린 뒤 이름 검색, 뜻 검색(유사도 0.71), 무관한 질문(0건), 임계값 0.9(0건)가 기대대로 나왔습니다. `ragEnabled` Agent도 실제 LLM 호출 1회로 올린 문서를 근거로 답했습니다. 삭제, 재삭제, 빈 파일(400)도 확인했습니다.

## 달라진 점

- **올린 직후에는 뜻으로 찾히지 않습니다.** 임베딩은 `dstone-knowledge`가 뒤에서 따로 하며, 이번 확인에서는 30~45초 걸렸습니다. 그 전에는 영문 이름이 글자 그대로 들어간 질문으로만 찾힙니다.
- **기존 `vector_store`의 문서는 옮기지 않았습니다.** 테이블은 지우지 않고 그대로 두었고, 코드만 더 이상 읽지 않습니다. 필요한 문서는 다시 올려야 합니다.
- **`dstone-knowledge`가 내려가 있으면 RAG 호출이 실패합니다.** 기동 직후 첫 검색은 임베딩 모델 로딩 때문에 한 번 타임아웃이 났습니다.
- **호출자별 문서 격리는 `dstone-ai-engine`이 문서 이름 앞에 호출자를 붙여서(`shop::약관.pdf`) 처리합니다.** `dstone-knowledge`가 보는 호출자가 엔진 하나뿐이기 때문입니다. 이 환경은 인증이 꺼져 있어 호출자가 있는 경우는 실행해 보지 못했습니다.
- **knowledge 쪽 변경은 한 줄입니다.** 검색 결과에 `documentId`를 추가했습니다.
- **`KnowledgeTool`은 컴파일만 확인했습니다.** HTTP 호출 코드를 RAG와 같이 쓰는 `KnowledgeClient`로 옮겼고, 같은 경로를 RAG 검색으로는 확인했지만 Tool 자체를 LLM으로 불러 보지는 않았습니다.

## 남은 일

- `dstone-ai-engine/k8s/configmap.yaml`은 오래된 최소 설정이라 datasource, knowledge 주소, RAG 설정이 없습니다. Pod로 올리기 전에 추가해야 합니다. 이번에는 손대지 않았습니다.
- 확인 과정에서 `dstone_ai` DB에 시험 실행 이력 3건이 남았습니다.
- 시험용으로 띄운 `dstone-ai-engine`과 `dstone-knowledge`는 모두 다시 내렸습니다.

문서는 `docs/09.dstone-ai-engine.md`, `docs/11.dstone-knowledge.md`(M9 중 ai-engine 쪽 완료로 표시), `docs/02.environment.md`, `docs/software/05.postgresql.md`, `CLAUDE.md`를 갱신했습니다.

---

## 질문

<pasted_content id="6b9e">
그럼 dstone-boot 에서 아래의 내용들이 수정되어야 하지 않나?
1. dstone AI > 채팅 
    문서검색(RAG) 체크박스 기능 정리 필요하지 않아?
2. dstone AI > 문서 임베딩 관리 
    이 메뉴는 삭제되어야 하지 않아?
</pasted_content id="6b9e">

---

## 답변

두 화면이 지금 어떻게 되어 있는지 먼저 확인하겠습니다.

---

## 답변

네, 2번은 맞고 1번은 절반만 맞습니다. 아직 수정하지는 않았고, 확인한 내용과 제안을 먼저 드립니다.

## 1. 채팅의 "문서검색(RAG)" 체크박스

기능은 지금도 그대로 동작합니다. 체크하면 고른 Agent에 `ragEnabled`가 켜지고, 검색만 `dstone-knowledge`로 가도록 바뀌었을 뿐입니다. 그래서 없앨 필요는 없고 설명만 정리하면 됩니다.

- 라벨을 "올린 문서 검색(RAG)"처럼 바꾸고, 문서를 어디서 올리는지(Knowledge > 검색 · 문서) 안내 한 줄을 붙입니다.
- AI 첫 화면과 Workflow 예시에 남아 있는 "RAG 문서 관리 화면에서 적재한…" 문구도 같이 고칩니다.

## 2. "문서 임베딩 관리" 메뉴

삭제하는 쪽이 맞습니다. 이유는 두 가지입니다.

- **기능이 겹칩니다.** Knowledge > 검색 · 문서 화면에 문서 올리기/목록/삭제가 이미 있고, 지금은 두 화면이 같은 저장소에 넣습니다.
- **목록이 실제와 어긋납니다.** 이 화면은 `dstone-boot` 자체 테이블(`TB_AI_DOCUMENT`)의 업로드 이력을 보여주기 때문에, Knowledge 화면에서 올리거나 지운 문서는 반영되지 않습니다.

삭제하면 달라지는 점은 다음과 같습니다.

- **업로드한 사람 기록이 없어집니다.** `TB_AI_DOCUMENT`에는 올린 사용자 ID가 남지만 `dstone-knowledge`는 그 정보를 저장하지 않습니다.
- **나중에 `dstone-ai-engine`의 API 키 인증을 켜면 문제가 생깁니다.** 인증된 호출자는 자기 이름이 붙은 문서만 검색하는데, Knowledge 화면에서 올린 문서에는 그 이름이 붙지 않아 RAG에 안 잡힙니다. 지금은 인증이 꺼져 있어 문제없습니다.

## 정해주실 것

삭제 범위를 어디까지 할지입니다.

- **권장안**: 메뉴, 화면(JSP·JS), 컨트롤러·서비스·Dao·매퍼는 삭제하고, `TB_AI_DOCUMENT` 테이블과 그 안의 이력은 DB에 남겨 둡니다. 스키마 파일에서는 정의를 빼고 "더 이상 쓰지 않음"으로 표시합니다.
- **대안**: 테이블까지 DROP합니다. 이력이 필요 없다는 확인이 있어야 합니다.

권장안으로 진행해도 될까요? 그러면 1번 문구 정리와 문서 갱신까지 함께 하겠습니다.

---

## 질문

진행해주되 더이상 사용되지 않는 리소스들(소스, 테이블 등... )은 모두 삭제해줘.

---

## 답변

진행하겠습니다. 삭제 대상을 먼저 빠짐없이 찾고, 지우기 전에 테이블 안의 내용도 확인합니다.

---

## 답변

Now the schema scripts, then the actual DB drops.

---

## 답변

소스·테이블 삭제와 화면 확인은 끝났습니다. 마지막으로 문서(`docs/06.dstone-boot.md` 등)에서 삭제한 화면을 설명하던 부분을 정리하고 있습니다.

---

## 답변

`dstone-boot` 정리를 마쳤고, 더 이상 쓰지 않는 소스와 테이블을 모두 삭제했습니다. 이번 변경분은 커밋하지 않았습니다(앞 작업분은 그사이 저장소에 커밋되어 있습니다).

## 1. 채팅의 RAG 체크박스

- 라벨을 "올린 문서 검색(RAG)"으로 바꾸고, 문서를 어디서 올리는지(코드 분석 > 검색 · 문서) 안내와 링크를 붙였습니다. 기능은 그대로입니다.
- AI 첫 화면의 설명과 Workflow 테스트의 예시 문구도 새 위치를 가리키도록 고쳤습니다.
- 코드 분석 > 검색 · 문서의 문서 올리기 안내에 "AI 채팅의 RAG도 여기서 올린 문서에서 찾는다"는 한 줄을 넣었습니다.

## 2. "문서 임베딩 관리" 삭제

- **화면과 소스**: 상단 메뉴 링크, 화면(JSP·JS), 컨트롤러·서비스·Dao·VO·매퍼 XML, 전용 CSS를 지웠습니다. 첫 화면의 카드는 코드 분석 > 검색 · 문서로 가는 "문서 올리기" 카드로 바꿨습니다.
- **스키마 파일**: `TB_AI_DOCUMENT` 정의, `dstone_ai` 초기화 스크립트의 확장 생성 구문을 뺐습니다.

## 실제 DB에서 삭제한 것

| DB | 삭제한 것 | 들어 있던 내용 |
|---|---|---|
| `sampleDB` (MySQL) | `TB_AI_DOCUMENT` | 업로드 이력 3건 (`ora-to-pg-0001`~`0003`, 모두 ADMIN01) |
| `dstone_ai` (PostgreSQL) | `vector_store` | 문서 1건(`ora-to-pg-0003`), 조각 24개 |
| `dstone_ai` | 확장 `vector`, `uuid-ossp`, `hstore` | `vector_store`용이었음 |
| `dstone_ai` | `analysis_*` 5개, `rag_*` 3개 테이블 | 모두 0건 |

마지막 줄의 8개 테이블은 요청 범위 밖에서 제가 발견한 것입니다. `dstone-knowledge` 스키마를 이 DB에 잘못 실행해서 생긴 것으로 보이고, 전부 비어 있었으며 `vector` 확장을 지우려면 함께 지워야 해서 삭제했습니다. 이제 `dstone_ai`에는 실행 이력 테이블 2개만 남았습니다.

## 확인한 것

`dstone-boot`를 clean 빌드로 다시 띄워 로그인한 뒤 확인했습니다. 메뉴에서 항목이 사라졌고, 옛 화면 주소는 404이며, 채팅 화면의 새 라벨과 안내가 보이고, 스크립트 오류는 없습니다. 확인 후 서버는 내렸습니다.

첫 확인 때는 수정 전 화면이 나왔고 원인은 확인하지 못했습니다. 그 빌드를 clean 없이 해서 삭제한 파일이 war에 남아 있던 것은 확인했습니다. 배포할 때는 `mvn clean package`로 빌드해야 합니다.

## 남겨 둔 것

- **`dstone-ai-engine`의 `/api/ai/embed/*` API**: 화면은 없어졌지만 엔진을 직접 호출하는 앱이 문서를 올리는 경로라 남겼습니다. 이것도 지우길 원하시면 말씀해 주세요.
- **`sampleDB`의 `TB_AI_SQLCONVERT` 테이블**: 저장소 어디에서도 참조하지 않는 테이블입니다. 이번 변경과 무관한 예전 "SQL 변환" 화면의 흔적으로 보여 손대지 않았습니다. 지워도 되는지 알려주시면 삭제하겠습니다.
- **인증을 켤 때 주의**: 나중에 `dstone-ai-engine`의 API 키 인증을 켜면, 코드 분석 화면에서 올린 문서는 인증된 호출자의 RAG 검색에 잡히지 않습니다. 인증을 켤 때 함께 정해야 합니다.

문서는 `docs/06.dstone-boot.md`(해당 절 삭제, 번호 정리), `docs/11.dstone-knowledge.md`, `docs/02.environment.md`, `docs/software/04.mysql.md`, `docs/software/05.postgresql.md`, `CLAUDE.md`를 갱신했습니다.

---

## 질문

dstone-ai-engine 에서도 삭제될 대상은 없는가?

---

## 답변

네, 있었습니다. 확실히 안 쓰는 것은 방금 지웠고, 판단이 필요한 두 가지는 남겨 두었습니다. 커밋은 하지 않았습니다.

## 지금 삭제·정리한 것

- **Lombok 의존성**: `dstone-ai-engine` 소스 어디에서도 쓰지 않아 `pom.xml`에서 뺐습니다.
- **테스트컨테이너 의존성**(`spring-ai-spring-boot-testcontainers`): 이 모듈에는 테스트 코드가 없어 함께 뺐습니다.
- **예제 YAML의 낡은 안내 3곳**: 없어진 "문서 임베딩 관리" 화면을 가리키던 문구를 "코드 분석(Knowledge) > 검색 · 문서"로 고쳤습니다. 지난 작업에서 제가 놓친 부분입니다.

clean 빌드는 통과했고, 산출물 jar에 Lombok·테스트컨테이너·pgvector·Tika 라이브러리가 없는 것을 확인했습니다. 이번에는 서버를 띄워 보지는 않았습니다.

## 정해주실 것: 문서 관리 API와 검색 미리보기 API

저장소 안에서 호출하는 곳이 없어진 API가 두 묶음 있습니다.

| 대상 | 내용 | 지우면 |
|---|---|---|
| `/api/ai/embed/*` (`EmbedController`, `EmbedService`, 응답 DTO 2개, 업로드 크기 설정) | 문서 올리기/삭제/목록을 `dstone-knowledge`로 넘기는 통로 | 문서를 올리는 경로가 코드 분석 화면(`dstone-knowledge` API) 하나로 정리됩니다 |
| `/api/ai/rag/search` (`RagController`) | LLM 없이 검색 결과만 보는 운영용 API | 같은 확인은 코드 분석 > 검색에서 "올린 문서"를 체크하면 됩니다 |

**둘 다 지우는 쪽을 권합니다.** 지우면 문서 이름 앞에 호출자를 붙이는 규칙(`RagSourceId`)도 함께 없앨 수 있고, 지난번에 말씀드린 "인증을 켜면 코드 분석 화면에서 올린 문서가 RAG에 안 잡히는 문제"가 사라집니다.

대신 포기하는 것이 하나 있습니다. 엔진을 호출하는 앱별로 문서를 가려 주는 기능이 없어져, 올린 문서는 모든 호출자가 함께 보게 됩니다. 지금은 인증이 꺼져 있어 실제 동작은 달라지지 않습니다. 앱별 격리가 나중에 필요하면 `dstone-knowledge` 쪽에서 다시 설계해야 합니다.

Agent의 `ragEnabled`와 `searchDocuments` Tool은 어느 쪽을 택해도 그대로 동작합니다.

## 삭제 대상이 아닌 것

- **Ollama 의존성과 설정**: 임베딩용으로는 안 쓰지만 채팅 모델 선택지(`spring.ai.model.chat: ollama`)라 남겼습니다.
- **`spring-ai-rag`**: `ragEnabled`가 검색 결과를 프롬프트에 붙일 때 씁니다.
- **`k8s/configmap.yaml`**: 삭제가 아니라 보완 대상입니다. datasource, knowledge 주소, RAG 설정이 빠진 옛 설정이라 Pod 배포 전에 채워야 합니다.

두 API를 권장대로 지울까요?

---

## 질문

응 지워줘 . 그리고 sampleDB의 TB_AI_SQLCONVERT 테이블도 삭제해줘.

---

## 답변

두 API와 `TB_AI_SQLCONVERT` 테이블을 삭제했고, 두 서버를 띄워 확인까지 마쳤습니다. 이번 변경분은 커밋하지 않았습니다.

## dstone-ai-engine에서 삭제한 것

- **문서 관리 API** `/api/ai/embed/*`: `EmbedController`, `EmbedService`, 응답 DTO 2개, 업로드 크기 설정.
- **검색 미리보기 API** `/api/ai/rag/search`: `RagController`, 요청 DTO.
- **호출자별 문서 이름 규칙**(`RagSourceId`)과 검색 체인·Tool에 남아 있던 호출자 구분 코드.
- **knowledge 호출 창구의 올리기·삭제 메소드**: 호출하는 곳이 없어져 함께 뺐습니다.

`ragEnabled`와 `searchDocuments` Tool은 그대로 두고 검색만 하도록 단순화했습니다.

## 삭제한 테이블

`sampleDB`의 `TB_AI_SQLCONVERT`를 DROP했습니다. 예전 "SQL 변환" 화면의 변환 이력 64건(2026-09-14 ~ 09-20)이 들어 있었고, 다른 테이블이 참조하지 않는 것을 확인한 뒤 지웠습니다. 스키마 파일에는 원래 정의가 없어 고칠 것이 없었습니다.

## 확인한 것

- 지운 두 API는 404로 응답합니다.
- `dstone-knowledge`에 문서를 직접 올린 뒤, RAG Tool 워크플로가 그 문서를 찾았습니다.
- `ragEnabled` Agent가 올린 문서를 근거로 답했습니다(LLM 호출 1회).
- 확인 후 시험 문서는 지웠고, 띄웠던 `dstone-knowledge`와 `dstone-ai-engine`은 모두 내렸습니다.

## 달라진 점

- **올린 문서는 엔진을 쓰는 모든 호출자가 함께 봅니다.** 앱별 격리가 필요해지면 `dstone-knowledge` 쪽에서 설계해야 합니다.
- **문서를 올리는 경로는 `dstone-knowledge` 하나입니다.** 코드 분석 > 검색 · 문서 화면이나 그 서버의 `/api/documents`를 씁니다. 지난번에 말씀드린 "인증을 켜면 화면에서 올린 문서가 RAG에 안 잡히는 문제"는 없어졌습니다.

문서는 `docs/09.dstone-ai-engine.md`, `docs/11.dstone-knowledge.md`, `CLAUDE.md`를 갱신했습니다.

---

## 질문

dstone-ai-engine, dstone-knowledge 화면 에 홈(dstone-boot)로 돌아오는 링크 붙여줘.

---

## 답변

AI 화면과 코드 분석(Knowledge) 화면의 상단 메뉴 맨 앞에 "← Dstone 홈" 링크를 붙였습니다. 누르면 `dstone-boot` 첫 화면(`/views/main`, 왼쪽 메뉴의 "main"과 같은 곳)으로 갑니다. 커밋은 하지 않았습니다.

- **위치**: 두 화면의 공통 헤더(`ai/common/header.jsp`, `knowledge/common/header.jsp`)에 넣어 각 화면의 모든 페이지에 나옵니다.
- **모양**: 그 화면의 메뉴가 아니라 나가는 링크라서, 굵은 글씨에 오른쪽 구분선을 두어 다른 메뉴와 구별했습니다.
- **확인**: 빌드한 war를 띄워 두 화면 모두에서 링크가 보이고, 눌렀을 때 `dstone-boot` 첫 화면이 열리는 것을 확인했습니다.

## 확인 중 알게 된 것

지금 `localhost:7081`에는 제가 띄우지 않은 `dstone-boot`가 응답하고 있습니다. WSL이 mirrored 네트워킹이라 Windows 쪽에서 띄운 인스턴스로 보이며, 건드리지 않았습니다.

- 그 인스턴스에는 이번 수정이 반영되어 있지 않습니다. 화면에서 보시려면 새로 빌드한 war로 다시 띄우셔야 합니다(`mvn clean package`).
- 제 확인은 포트를 7181로 바꿔 따로 띄워서 했고, 끝난 뒤 내렸습니다.
- 지난번 "문서 임베딩 관리" 삭제 확인 때 첫 시도에서 수정 전 화면이 나왔던 원인도 이것으로 보입니다. 당시 재확인은 제 인스턴스가 포트를 잡은 것을 확인한 뒤에 했으므로 그 결과는 유효합니다.

다음부터 같은 착오가 없도록 이 환경 사실을 메모리에 저장했습니다. 문서는 `docs/06.dstone-boot.md`와 `docs/11.dstone-knowledge.md`에 링크 설명을 한 줄씩 추가했습니다.

---

## 질문

<pasted_content id="6b9e">
2026-10-06 01:25:39 ERROR [net.dstone.knowledge.common.exception.ApiExceptionHandler] 처리 중 오류가 났습니다.
org.springframework.http.converter.HttpMessageNotWritableException: Could not write JSON: ServletOutputStream failed to write: java.io.IOException: 현재 연결은 사용자의 호스트 시스템의 소프트웨어의 의해 중단되었습니다
    at org.springframework.http.converter.AbstractJacksonHttpMessageConverter.writeInternal(AbstractJacksonHttpMessageConverter.java:444)
    at org.springframework.http.converter.AbstractSmartHttpMessageConverter.write(AbstractSmartHttpMessageConverter.java:116)
    at org.springframework.web.servlet.mvc.method.annotation.AbstractMessageConverterMethodProcessor.writeWithMessageConverters(AbstractMessageConverterMethodProcessor.java:342)
    at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.handleReturnValue(RequestResponseBodyMethodProcessor.java:213)
    at org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite.handleReturnValue(HandlerMethodReturnValueHandlerComposite.java:77)
    at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:135)
    at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:934)
    at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:853)
    at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:86)
    at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)
    at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:866)
    at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:1000)
    at org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:903)
    at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:649)
    at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:874)
    at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:710)
    at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:132)
    at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:59)
    at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:111)
    at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:101)
    at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:111)
    at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:100)
    at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:116)
    at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:111)
    at org.springframework.web.filter.FormContentFilter.doFilterInternal(FormContentFilter.java:93)
    at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:116)
    at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:111)
    at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:199)
    at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:116)
    at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:111)
    at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:165)
    at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:77)
    at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:535)
    at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:115)
    at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:86)
    at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:71)
    at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:347)
    at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:406)
    at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:71)
    at org.apache.coyote.AbstractProtocol$ConnectionHandler.process(AbstractProtocol.java:1307)
    at org.apache.tomcat.util.net.NioEndpoint$SocketProcessor.doRun(NioEndpoint.java:2036)
    at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:74)
    at org.apache.tomcat.util.threads.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:949)
    at org.apache.tomcat.util.threads.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:483)
    at org.apache.tomcat.util.threads.TaskThread$WrappingRunnable.run(TaskThread.java:74)
    at java.base/java.lang.Thread.run(Thread.java:1583)
Caused by: tools.jackson.databind.DatabindException: ServletOutputStream failed to write: java.io.IOException: 현재 연결은 사용자의 호스트 시스템의 소프트웨어의 의해 중단되었습니다
</pasted_content id="6b9e">

---

## 답변

시험용으로 띄운 knowledge(4181 포트)가 아직 살아 있어 정리하는 중입니다.

---

## 답변

이 오류는 `dstone-knowledge`의 처리 실패가 아니라, **호출한 쪽이 응답을 받기 전에 연결을 끊어서** 생긴 것입니다. 서버가 결과를 다 만들어 보내려는데 받을 상대가 이미 없었던 상황입니다.

## 원인

로그 한 건만으로는 어떤 호출이었는지 특정할 수 없습니다. 스택으로 알 수 있는 것은 POST 요청이었다는 것뿐입니다. 가능한 경우는 이렇습니다.

- **제 확인 작업일 가능성**: 로그 시각 `01:25:39`는 콘솔 로그가 12시간제라서 실제로는 13:25:39입니다. 그 무렵 제가 홈 링크 확인용으로 띄웠던 `dstone-boot`(7181 포트)를 강제 종료했는데, 그 인스턴스가 사용자님 쪽 `dstone-knowledge`(4081)를 호출하던 중이었을 수 있습니다. 확인하지는 못했습니다.
- **호출한 쪽의 대기 시간 초과**: `dstone-ai-engine`은 60초, `dstone-boot` 중계는 120초입니다. 임베딩 서버가 바쁘면 검색이 그보다 오래 걸릴 수 있습니다.
- **응답 크기 초과**: 오늘 수정 전의 `dstone-boot` 중계는 256KB까지만 받고 연결을 끊습니다.
- **브라우저를 닫았거나 화면을 떠난 경우**.

같은 오류가 다시 나면 아래 수정 덕분에 어떤 호출이었는지 로그에 남습니다.

## 고친 것

`dstone-knowledge`의 공통 오류 처리(`ApiExceptionHandler`)를 수정했습니다. 커밋은 하지 않았습니다.

- **연결 끊김은 한 줄 경고로만 남깁니다.** 긴 스택과 함께 ERROR로 찍히던 것이 `부른 쪽이 응답을 받기 전에 연결을 끊었습니다: GET /api/...` 형태의 WARN 한 줄이 됩니다.
- **진짜 오류 로그에도 호출 주소가 함께 찍힙니다.**

다른 포트(4181)로 띄워 응답 도중 클라이언트가 끊는 상황을 두 번 만들어 확인했습니다. 두 번 모두 한 줄 경고만 남고 스택은 없었으며, 정상 호출과 404 응답은 그대로입니다. 시험용 프로세스는 내렸습니다.

사용자님이 띄워 둔 `dstone-knowledge`에는 새로 빌드해 다시 띄워야 반영됩니다.

## 함께 발견한 것

모든 모듈의 콘솔 로그 시각이 12시간제(`hh`)로 찍혀 오전·오후를 구분할 수 없습니다. 파일 로그는 24시간제(`HH`)입니다. 각 모듈의 `conf/log4j2.xml`과 k8s configmap 두 곳에서 한 글자씩 바꾸면 되는데, 이번에는 손대지 않았습니다. 원하시면 일괄로 고치겠습니다.

---

## 질문

일괄로 수정해줘. 그리고 git에 올려줘.

---

## 답변

콘솔 로그 시각을 24시간제로 일괄 수정했고, GitHub `main`에 푸시했습니다 (커밋 `d109f40`).

- **수정한 곳**: 6개 모듈의 `conf/log4j2.xml`과 `dstone-boot`·`dstone-ai-engine`의 `k8s/configmap.yaml`, 총 8개 파일에서 콘솔 패턴의 `hh`를 `HH`로 바꿨습니다. 저장소에 12시간제 패턴은 남아 있지 않습니다.
- **함께 올린 것**: 직전에 고친 `dstone-knowledge`의 연결 끊김 로그 처리(`ApiExceptionHandler`)도 같은 커밋에 넣었습니다.
- **확인**: 고친 XML과 YAML이 형식상 깨지지 않았는지만 확인했습니다. 설정 한 글자 변경이라 서버를 띄워 로그를 찍어 보지는 않았습니다.
- **브랜치**: 이 저장소가 `main`에 직접 올리는 방식이라 별도 브랜치 없이 `main`에 커밋했습니다.

오늘 앞서 작업한 내용(노드 맵, MyBatis 전환, RAG 연동, 화면·테이블 정리, 홈 링크)은 이미 `main`에 올라가 있어서, 지금 미커밋 변경은 없습니다.

실행 중인 서버에는 재기동해야 반영되고, kind에 올린 Pod는 configmap을 다시 적용해야 합니다.

---

## 질문

<pasted_content id="6b9e">

 {executed in 7 msec}
2026-10-06 13:35:26  WARN [net.dstone.knowledge.common.exception.ApiExceptionHandler] 부른 쪽이 응답을 받기 전에 연결을 끊었습니다: POST /api/search (부른 쪽의 대기 시간이나 수신 크기 한도를 확인하세요) - HttpMessageNotWritableException: Could not write JSON: ServletOutputStream failed to write: java.io.IOException: 현재 연결은 사용자의 호스트 시스템의 소프트웨어의 의해 중단되었습니다
2026-10-06 14:01:03  WARN [net.dstone.knowledge.rag.EmbeddingWorker] 임베딩 실패(16건, 연속 1번째): ResourceAccessException: I/O error on POST request for "http://localhost:11434/api/embed": Connection reset - 30초 뒤에 다시 시도합니다.
2026-10-06 14:01:06  WARN [com.zaxxer.hikari.pool.HikariPool] HikariPool-1 - Thread starvation or clock leap detected (housekeeper delta=21m59s170ms574µs300ns).
</pasted_content id="6b9e">

---

## 답변

네, 원인을 찾았고 고쳤습니다. 검색 자체가 느린 것이 아니라, **백그라운드 임베딩이 임베딩 서버를 붙잡고 있어서 검색이 그 뒤에 줄을 선 것**이었습니다. 아직 커밋하지 않았습니다.

## 원인

- **임베딩 서버(Ollama)는 요청을 한 번에 하나씩 처리합니다.** 검색 때 필요한 "질문 한 줄 임베딩"은 혼자면 0.1초인데, 대기열을 비우는 작업이 보낸 묶음이 끝날 때까지 기다려야 했습니다.
- **이 PC는 GPU 없이 CPU로 임베딩합니다.** 3,500자 조각 하나에 약 4초가 걸려서, 16건 한 묶음이 66.8초였습니다. Windows 쪽 그래픽은 AMD Radeon 780M 내장형이라 Ollama가 쓰지 못합니다.
- **대기열에 2,400여 건이 남아 있었습니다.** 그동안 검색이 59초에서 100초 이상 걸렸고, `dstone-ai-engine`의 대기 시간 60초를 넘겼습니다.
- **RAG 검색 실패 하나가 워크플로 전체를 중단시켰습니다.** 보내주신 로그의 `pilot-workflow` step01 실패가 이것입니다.

로그의 14:01 두 줄(임베딩 `Connection reset`, Hikari `clock leap 21m59s`)은 별개입니다. PC가 약 22분간 절전 상태였다가 깨어나며 생긴 것으로 보이고, 임베딩 작업은 30초 뒤 스스로 재시도합니다.

## 고친 것

| 어디 | 내용 |
|---|---|
| `dstone-knowledge` | 검색이 진행 중이거나 막 끝난 직후에는 백그라운드 임베딩이 새 묶음을 보내지 않고 양보합니다 (`EmbeddingGate`) |
| `dstone-knowledge` | 임베딩 묶음 크기를 16에서 1로 줄였습니다 (`conf/application.yml`의 `batch-size`). 검색이 기다리는 최대 시간이 한 건(약 4초)으로 줄어듭니다 |
| `dstone-ai-engine` | RAG 검색이 실패해도 경고만 남기고 참고자료 없이 진행합니다. `ragAllowEmptyContext: false`로 설정한 Agent만 실패합니다 |
| `dstone-ai-engine` | 시간 초과일 때 "서버가 떠 있는지 확인" 대신 "N초 안에 답하지 않았습니다"로 안내합니다 |
| `dstone-knowledge` | 연결 끊김 경고에 경과 시간과 호출자를 함께 남깁니다 |

묶음을 1로 줄여도 처리 속도는 같습니다. CPU에서는 16건 66.8초, 4건 16.5초로 건당 시간이 같았기 때문입니다.

## 확인한 것

- **검색 시간**: 같은 대기열이 도는 상태에서 새 `dstone-knowledge`로 검색 8번이 0.9~1.9초였습니다 (수정 전 59~100초).
- **RAG 실패 시 동작**: `dstone-knowledge`에 닿지 못하게 한 상태에서 `ragEnabled` Agent가 "참고자료 없이 답변드립니다"로 정상 응답했고, 경고 로그가 남았습니다.
- 시험은 다른 포트(4181, 8181)에서 했고 프로세스는 모두 내렸습니다. 띄워 두신 서버는 건드리지 않았습니다.

## 남는 한계

- **대기열 처리 자체는 여전히 느립니다.** 큰 조각 기준 분당 15건 정도라 남은 2,400여 건에 2~3시간이 걸리고, 검색이 잦으면 더 늦어집니다. 임베딩을 빠르게 하려면 GPU가 있는 서버가 필요합니다.
- **임베딩이 안 끝난 조각은 뜻으로는 찾히지 않습니다.** 이름 검색으로는 찾힙니다.

띄워 두신 서버에는 새로 빌드해 다시 띄워야 반영됩니다. 문서는 `docs/09`, `docs/11`, `CLAUDE.md`에 원인과 측정값을 기록했습니다. git에 올릴까요?

---

## 질문

현재 임베딩 작업이 얼마나 밀려있고 완료되려면 얼마나 걸리나?

---

## 답변

지금 밀린 임베딩은 **2,174건**(약 329만 자)이고, 다 끝내는 데 **약 1시간~1시간 반**이 걸릴 것으로 추정합니다. 다만 현재는 `dstone-knowledge`가 내려가 있어서 대기열이 전혀 줄지 않고 있습니다.

## 현재 상태

| 항목 | 값 |
|---|---|
| 임베딩 완료 | 14,798건 |
| 대기 중 | 2,430건 (실제 처리할 것 2,174건 + 지워진 리비전의 잔여 256건) |
| 최근 1분간 처리 | 0건 |
| `dstone-knowledge` (4081) | 응답 없음 |
| Ollama | 떠 있으나 올라온 모델 없음 (일하지 않는 상태) |

잔여 256건은 가리키는 문서가 이미 없어진 것이라, 작업이 돌 때 임베딩 없이 대기열에서 빠집니다.

## 대기열에 남은 것

| 프로젝트 | 종류 | 건수 | 평균 글자 수 |
|---|---|---|---|
| `anybiz_prd` | 화면(JSP) | 625 | 3,186 |
| `testApp` | 메소드 | 590 | 926 |
| `anybiz_prd` | 메소드 | 약 240 | 550 |
| `cms4_prd` | 메소드 | 144 | 561 |
| `testApp` | 타입·파일·SQL·화면 | 328 | 458~2,770 |
| `dstone-boot`, `dstone-batchadmin` | 여러 종류 | 약 240 | 373~2,332 |

`anybiz_prd`는 리비전 두 개(28, 42)가 같은 내용을 공유해서 한 번만 임베딩하면 됩니다. 전체 글자 수의 60%가 `anybiz_prd` 화면(JSP) 625건에 몰려 있습니다.

## 소요 시간 추정

- **근거**: 아까 잰 속도가 1,000자당 약 1.2초입니다 (3,500자 조각 16건에 66.8초).
- **계산**: 329만 자 × 1.2초 ÷ 1,000 ≈ 65분입니다.
- **실제**: 검색이 끼어들면 그만큼 늦어지므로 1시간~1시간 반으로 봅니다. 추정치이고 끝까지 돌려서 확인한 값은 아닙니다.

## 진행하려면

`dstone-knowledge`를 띄워 두기만 하면 알아서 처리합니다. 진행 상황은 `GET /api/revisions/{id}/rag`나 코드 분석 화면의 리비전 요약 "임베딩 진행"에서 볼 수 있습니다.

방금 고친 버전(검색 우선 양보, 묶음 크기 1)은 아직 커밋 전입니다. 새 버전으로 띄우면 대기열이 도는 동안에도 검색이 1~2초에 끝납니다. 올려 드릴까요?
