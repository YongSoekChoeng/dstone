# dstoneboot_를_로컬에서_실행

> 생성일시: 2026-09-04 09:25

## 질문

dstone-boot 를 로컬에서 실행했을 때 아래와 같은 에러가 발생해.
이부분 해결해줘.

SLF4J(W): Class path contains multiple SLF4J providers.
SLF4J(W): Found provider [org.apache.logging.slf4j.SLF4JServiceProvider@564fabc8]
SLF4J(W): Found provider [ch.qos.logback.classic.spi.LogbackServiceProvider@16d04d3d]
SLF4J(W): See https://www.slf4j.org/codes.html#multiple_bindings for an explanation.
SLF4J(I): Actual provider is of type [org.apache.logging.slf4j.SLF4JServiceProvider@564fabc8]
Exception in thread "main" java.lang.ExceptionInInitializerError
    at org.springframework.boot.builder.SpringApplicationBuilder.createSpringApplication(SpringApplicationBuilder.java:115)
    at org.springframework.boot.builder.SpringApplicationBuilder.<init>(SpringApplicationBuilder.java:102)
    at org.springframework.boot.builder.SpringApplicationBuilder.<init>(SpringApplicationBuilder.java:98)
    at net.dstone.boot.DstoneBootApplication.main(DstoneBootApplication.java:44)
Caused by: org.apache.logging.log4j.LoggingException: log4j-slf4j2-impl cannot be present with log4j-to-slf4j
    at org.apache.logging.slf4j.Log4jLoggerFactory.validateContext(Log4jLoggerFactory.java:67)
    at org.apache.logging.slf4j.Log4jLoggerFactory.newLogger(Log4jLoggerFactory.java:49)
    at org.apache.logging.slf4j.Log4jLoggerFactory.newLogger(Log4jLoggerFactory.java:32)
    at org.apache.logging.log4j.spi.AbstractLoggerAdapter.getLogger(AbstractLoggerAdapter.java:52)
    at org.apache.logging.slf4j.Log4jLoggerFactory.getLogger(Log4jLoggerFactory.java:32)
    at org.slf4j.LoggerFactory.getLogger(LoggerFactory.java:447)
    at org.apache.commons.logging.LogAdapter$Slf4jAdapter.createLocationAwareLog(LogAdapter.java:121)
    at org.apache.commons.logging.LogAdapter.createLog(LogAdapter.java:95)
    at org.apache.commons.logging.LogFactory.getLog(LogFactory.java:67)
    at org.apache.commons.logging.LogFactory.getLog(LogFactory.java:59)
    at org.springframework.boot.SpringApplication.<clinit>(SpringApplication.java:202)
    ... 4 more

---

## 답변

dstone-boot 클래스패스에 SLF4J 바인딩이 두 개(log4j2 계열 + logback) 들어가 있어서 나는 에러네요. pom.xml을 확인해서 원인을 찾아볼게요.

---

## 답변

spring-boot-starter-web에서만 spring-boot-starter-logging을 제외했고, actuator/websocket/webflux 등 다른 스타터들은 제외 처리가 안 되어 있어서 logback이 다시 딸려 들어오는 것 같습니다. dependency:tree로 확인해볼게요.

---

## 답변

dstone-common엔 문제 없네요. dstone-boot 쪽에서 확인해보겠습니다.

---

## 답변

원인을 확인했습니다. `dstone-boot/pom.xml`의 `spring-boot-starter-actuator`가 `spring-boot-starter-logging`(logback + log4j-to-slf4j)을 끌어오는데, exclusion이 걸려있지 않아서 `dstone-common`이 제공하는 log4j2 구현체와 충돌하는 거였습니다. actuator에 동일한 exclusion을 추가하겠습니다.

---

## 답변

Exclusion을 추가한 후 트리를 다시 확인해서 정말 해결됐는지 검증하겠습니다.

---

## 답변

logback과 log4j-to-slf4j가 사라지고 log4j-slf4j2-impl만 남았습니다. 다른 스타터(webflux, websocket 등)도 같은 방식으로 새는 것이 없는지 dstone-common 전체를 한 번 더 점검하겠습니다.

---

## 답변

dstone-common 전체 트리에도 logback/log4j-to-slf4j가 없습니다. 이제 실제로 빌드하고 로컬에서 기동해서 에러가 사라졌는지 확인하겠습니다.

---

## 답변

Build succeeds. Let's try running it locally to confirm the SLF4J error is gone.

---

## 답변

No SLF4J warnings/errors in the output anymore. Let's peek at what actually happened during the run to make sure it's a normal (e.g., DB/Redis connection) failure and not a new logging issue.

---

## 답변

SLF4J 충돌 에러는 해결됐습니다 (로그에 더 이상 SLF4J 경고/에러가 없음). 이어서 뜨는 에러는 별개의 문제입니다.

---

## 답변

## 원인 및 조치

`dstone-boot/pom.xml`의 `spring-boot-starter-actuator`가 전이 의존성으로 `spring-boot-starter-logging`(logback-classic + log4j-to-slf4j)을 끌어오고 있었습니다. `dstone-common`은 `spring-boot-starter-web`에만 이 exclusion을 걸어뒀는데, actuator에는 걸려있지 않아서 `dstone-boot`에서만 logback과 log4j2가 동시에 classpath에 올라가 `log4j-slf4j2-impl cannot be present with log4j-to-slf4j` 에러가 발생한 것이었습니다.

`spring-boot-starter-actuator`에도 동일하게 `spring-boot-starter-logging` exclusion을 추가해서 (`dstone-boot/pom.xml:53-60`) 해결했습니다. `dependency:tree`로 확인한 결과 이제 `log4j-slf4j2-impl`만 남고 logback/log4j-to-slf4j는 사라졌고, 실제로 실행해봐도 SLF4J 관련 에러는 더 이상 나지 않습니다.

## 별개로 발견한 문제

수정 후 실행해보니 다음 에러가 새로 나옵니다 (SLF4J 문제와는 무관):

```
Config data resource 'file [D:/AppHome/framework/dstone/dstone-boot/conf/application.yml]' does not exist
```

`conf/env.properties`의 `APP_HOME`/`APP_CONF_DIR`/`FILE_UPLOAD_ROOT`가 Windows 경로(`D:/AppHome/framework`)로 되어 있어서입니다. 같은 디렉토리에 WSL용 값(`/app/dstone/...`)이 담긴 `conf/env-wsl.properties`가 이미 준비되어 있으니, 로컬(WSL)에서 돌리시려면 이 파일 내용으로 `env.properties`를 교체(또는 심볼릭 링크)하면 될 것 같습니다. 이건 별개 사안이라 원하시면 바로 처리해 드릴게요.
